import * as React from 'react';
import { Text, View, StyleSheet } from 'react-native';
import {createAppContainer} from 'react-navigation'
import HomeScreen from './Screens/HomeScreen'
// You can import from local files
export default class App extends React.Component{
  render(){
    return <HomeScreen />
  }

}